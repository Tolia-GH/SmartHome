create function fill_list_script_user() returns SETOF smart_home.list_script_user
    language plpgsql
as
$$ DECLARE
    i int = 0; BEGIN
    while i < 100000 loop
            insert into list_script_user(user_id, script_id) values (i + 1,i*10+1),(i + 1,i*10+2),(i +
                                                                                                   1,i*10+3),(i + 1,i*10+4),(i + 1,i*10+5),(i + 1,i*10+6),(i + 1,i*10+7),(i + 1,i*10+8),(i + 1,i*10+9),(i + 1,i*10+10);
            i = i + 1; end loop;
    return query select * from list_script_user limit 500; end;
$$;

alter function fill_list_script_user() owner to postgres;

