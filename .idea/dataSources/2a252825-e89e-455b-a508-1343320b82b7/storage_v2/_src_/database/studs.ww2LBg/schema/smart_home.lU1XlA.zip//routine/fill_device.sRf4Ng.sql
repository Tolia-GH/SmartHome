create function fill_device() returns SETOF smart_home.device
    language plpgsql
as
$$
DECLARE
    i int = 0;
    ft device_type[] = array ['AIR_CONDITION','LIGHT', 'HUMIDIFIER', 'BATHTUB', 'OUTLET','CURTAINS', 'FAN', 'CAMERA', 'WATER_HEATER'];
BEGIN
    while i < 300000 loop
            insert into device(room_id, manufacture, device_type) values (i+1,'xiaomi',ft[i%9+1]),(i+1,'xiaomi',ft[i%9+1]);
            i = i + 1;
        end loop;
    return query select * from device limit 500;
end;
$$;

alter function fill_device() owner to postgres;

