create function fill_sensor() returns SETOF smart_home.sensor
    language plpgsql
as
$$
DECLARE
    i int = 0;
    ft sensor_type[] = array ['TEMPERATURE', 'HUMIDITY', 'SMOKE'];
BEGIN
    while i < 300000 loop
            insert into sensor(room_id, manufacture, sensor_type) values (i+1,'xiaomi',ft[i%3+1]),(i+1,'xiaomi',ft[i%3+1]);
            i = i + 1;
        end loop;
    return query select * from sensor limit 500;
end;
$$;

alter function fill_sensor() owner to postgres;

