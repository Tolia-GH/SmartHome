create function fill_condition_script() returns SETOF smart_home.condition_script
    language plpgsql
as
$$ DECLARE
    i int = 0; BEGIN
    while i < 500000 loop
            insert into condition_script(script_id, condition_text) VALUES (i+1,'click button') ; i = i + 1;
        end loop;
    return query select * from condition_script limit 500;
end;
$$;

alter function fill_condition_script() owner to postgres;

