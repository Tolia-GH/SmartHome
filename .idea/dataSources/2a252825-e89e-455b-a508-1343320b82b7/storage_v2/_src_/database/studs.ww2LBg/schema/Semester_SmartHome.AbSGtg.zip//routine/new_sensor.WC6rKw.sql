create function new_sensor() returns trigger
    language plpgsql
as
$$
BEGIN
    IF ((SELECT COUNT(*) FROM sensor WHERE room_id = NEW.room_id) + (SELECT COUNT(*) FROM device WHERE room_id = NEW.room_id) >= 10) THEN
        RAISE EXCEPTION 'Room is filled.';
    ELSIF ((SELECT COUNT(*) FROM sensor WHERE room_id = NEW.room_id) + (SELECT COUNT(*) FROM device WHERE room_id = NEW.room_id) >= 9) THEN
        UPDATE room SET is_filled = TRUE WHERE room.id = NEW.room_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function new_sensor() owner to postgres;

