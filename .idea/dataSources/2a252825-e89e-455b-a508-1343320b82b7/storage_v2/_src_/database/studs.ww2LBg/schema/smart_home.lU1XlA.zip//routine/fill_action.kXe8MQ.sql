create function fill_action() returns SETOF smart_home.device_action
    language plpgsql
as
$$
DECLARE
    i int = 0;
    ft device_type[] = array ['AIR_CONDITION','LIGHT', 'HUMIDIFIER', 'BATHTUB', 'OUTLET','CURTAINS', 'FAN', 'CAMERA', 'WATER_HEATER'];
BEGIN
    while i < 9 loop
            insert into device_action(device_type, action_type, description) values (ft[i%9+1],'TURN_ON','Test'),  (ft[i%9+1],'TURN_OFF','Test')
                                                                       ,  (ft[i%9+1],'SWITCH_OFF','Test'),  (ft[i%9+1],'SWITCH_OFF','Test');
            i = i + 1;
        end loop;
    return query select * from device_action limit 500;
end;
$$;

alter function fill_action() owner to postgres;

