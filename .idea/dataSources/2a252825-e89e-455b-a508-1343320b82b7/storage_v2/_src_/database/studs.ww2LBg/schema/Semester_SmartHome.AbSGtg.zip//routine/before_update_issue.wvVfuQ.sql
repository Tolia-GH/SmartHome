create function before_update_issue() returns trigger
    language plpgsql
as
$$
BEGIN
    IF((SELECT COUNT(*) FROM issue WHERE supporter_id = NEW.supporter_id AND issue.is_finished = FALSE)>=5 and NEW.is_finished = FALSE) THEN
        RAISE EXCEPTION 'Dispatch a problem to a busy support man is forbidden';
    END IF;
    RETURN NEW;
END;
$$;

alter function before_update_issue() owner to postgres;

