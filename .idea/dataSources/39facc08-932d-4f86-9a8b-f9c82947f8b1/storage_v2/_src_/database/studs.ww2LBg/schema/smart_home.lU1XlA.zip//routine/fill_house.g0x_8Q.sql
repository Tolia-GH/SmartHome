create function fill_house() returns SETOF smart_home.address
    language plpgsql
as
$$
DECLARE
    i int = 0;
    houses house_type[] = array ['APARTMENTS', 'VILLAS', 'HIGH_END','ORDINARY'];
BEGIN
    while i < 100000 loop
            insert into house(address_id, house_type) VALUES (i+1,houses[i%4+1]);
            i = i + 1;
        end loop;
    return query select * from address limit 500;
end;
$$;

alter function fill_house() owner to postgres;

