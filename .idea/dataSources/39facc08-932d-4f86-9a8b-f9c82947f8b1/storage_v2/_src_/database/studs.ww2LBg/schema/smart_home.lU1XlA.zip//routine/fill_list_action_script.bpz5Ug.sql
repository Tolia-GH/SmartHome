create function fill_list_action_script() returns SETOF smart_home.list_action_script
    language plpgsql
as
$$ DECLARE
    i int = 0; BEGIN
    while i < 1000000 loop
            insert into list_action_script(script_id, action_id) values (i+1,1),(i+1,2),(i+1,3); i = i + 1;
        end loop;
    return query select * from list_action_script limit 500;
end;
$$;

alter function fill_list_action_script() owner to postgres;

