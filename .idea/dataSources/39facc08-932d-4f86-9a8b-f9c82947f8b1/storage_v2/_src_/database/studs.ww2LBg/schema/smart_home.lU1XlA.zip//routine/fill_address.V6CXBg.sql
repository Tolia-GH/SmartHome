create function fill_address() returns SETOF smart_home.address
    language plpgsql
as
$$
DECLARE
    i int = 0;
    countries country[] = array ['US','UK','RUSSIAN','CHINA','FRANCE'];
    cities city[] = array ['SHANGHAI', 'BEIJING', 'SHENZHEN', 'GUANGZHOU', 'CHENGDU','PARIS', 'MARSEILLE', 'LYON', 'TOULOUSE','CAMBRIDGE', 'EDINBURGH',  'LONDON', 'LIVERPOOL','NEW_YORK', 'LOS_ANGELES', 'CHICAGO', 'BOSTON'];
BEGIN
    while i < 200000 loop
            insert into address(country, city, street) VALUES (countries[i%5+1],cities[i%17+1],'xx streest');
            i = i + 1;
        end loop;
    return query select * from address limit 500;
end;
$$;

alter function fill_address() owner to postgres;

