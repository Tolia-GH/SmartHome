create function fill_address() returns SETOF smart_home.address
    language plpgsql
as
$$
DECLARE
    i int = 0;
    countries country[] = array ['US','UK','RUSSIAN','CHINA','FRANCE'];
    cities city[] = array ['Shanghai', 'Beijing', 'Shenzhen', 'Guangzhou', 'Chengdu','Paris', 'Marseille', 'Lyon', 'Toulouse','Cambridge', 'Edinburgh',  'London', 'Liverpool','NewYork', 'LosAngeles', 'Chicago', 'Boston'];
BEGIN
    while i < 10 loop
            insert into address(country, city, street) VALUES (countries[i%5+1],cities[i%17+1],'xx streest');
            i = i + 1;
        end loop;
    return query select * from address limit 500;
end;
$$;

alter function fill_address() owner to postgres;

