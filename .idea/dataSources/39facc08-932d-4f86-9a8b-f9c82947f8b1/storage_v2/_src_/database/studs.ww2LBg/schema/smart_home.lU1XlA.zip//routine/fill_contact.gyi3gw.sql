create function fill_contact() returns SETOF smart_home.contact
    language plpgsql
as
$$
DECLARE
    i int = 0;
BEGIN
    while i < 100 loop
            insert into contact(user_id, email, phone_num)  VALUES (i+1,to_char(i,'9999999')||'@gmail.com',to_char(i,'99999999')) ;
            i = i + 1;
        end loop;
    return query select * from contact limit 500;
end;
$$;

alter function fill_contact() owner to postgres;

