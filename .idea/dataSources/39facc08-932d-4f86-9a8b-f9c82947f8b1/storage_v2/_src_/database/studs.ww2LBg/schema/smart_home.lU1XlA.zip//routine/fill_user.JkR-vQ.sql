create function fill_user() returns SETOF smart_home."user"
    language plpgsql
as
$$
DECLARE
i int = 0;
names varchar(64)[] = array ['Peter','Bob','John','Tomas','Alex','Anna'];
BEGIN
    while i < 10000 loop
            insert into "user"(username,gender,password,age) values (names[i%6+1],'MALE',random()*1000,28);
            i = i + 1;
end loop;
return query select * from "user" limit 500;
end;
$$;

alter function fill_user() owner to postgres;

